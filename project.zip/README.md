# jss-final-project
SI 206 Fall 2023 - Final Project

Team members: Sarah Hubbard, Sarah Penrose, Jennifer Kim
